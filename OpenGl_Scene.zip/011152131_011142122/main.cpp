#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <windows.h>
#include <glut.h>
#define  pi (2*acos(0.0))

double cameraHeight;
double cameraAngle;

int drawgrid;
int drawaxes;

double angle = 0;
double incx  = 50;
double incy;
int state;

float v  = 0.3;
float w  = 0.3;
float q  = 0;
float q2 = 0;

const float clockR    = 80.0f,
            clockVol  = 100.0f,

            angle1min = M_PI / 30.0f,

            minStart  = 0.9f,
            minEnd    = 1.0f,

            stepStart = 0.8f,
            stepEnd   = 1.0f;

float angleHour = 0,
      angleMin  = 0,
      angleSec  = 0;


struct point
{
	double x,y,z;
};


void drawAxes()
{

		glColor3f(1.0, 1.0, 1.0);
		glBegin(GL_LINES);{
			glVertex3f( 100,0,0);
			glVertex3f(-100,0,0);

			glVertex3f(0,-100,0);
			glVertex3f(0, 100,0);

			glVertex3f(0,0, 100);
			glVertex3f(0,0,-100);
		}glEnd();

}


void drawGrid()
{
	int i;

    glColor3f(0.6, 0.6, 0.6);	//grey
    glBegin(GL_LINES);{
        for(i=-8;i<=8;i++){

            if(i==0)
                continue;	//SKIP the MAIN axes

            //lines parallel to Y-axis
            glVertex3f(i*10, -90, 0);
            glVertex3f(i*10,  90, 0);

            //lines parallel to X-axis
            glVertex3f(-90, i*10, 0);
            glVertex3f( 90, i*10, 0);
        }
    }glEnd();

}

void drawSquare(double a)
{
	glBegin(GL_QUADS);
	{
        glColor3f(0.9,0.0,.7);
		glVertex3f( a, a,2);

        glColor3f(1.0,1.0,1.0);
		glVertex3f( a,-a,2);

        glColor3f(.0,.3,0.9);
        glVertex3f(-a,-a,2);

        glColor3f(.0,.7,.1);
		glVertex3f(-a, a,2);
	}
	glEnd();
}



void drawSquare2(double a)
{
	glBegin(GL_QUADS);
	{
		glVertex3f( a, a,2);
		glVertex3f( a,-a,2);
        glVertex3f(-a,-a,2);
		glVertex3f(-a, a,2);
	}
	glEnd();
}


void drawCircle(float radius_x, float radius_y)
{
	int i = 0;
	float angle = 0.0;
	glBegin(GL_POLYGON);
    {
		for(i = 0; i < 60; i++)
		{
			angle = 2 * 3.1416 * i / 60;
			glVertex3f (cos(angle) * radius_x, sin(angle) * radius_y, 0);
		}

    }

	glEnd();
}


void draw_rec()
{
    //glColor3f(0,1,0);

    drawSquare(5);

}


void draw_rec2()
{
    //glColor3f(0,1,0);

    drawSquare2(5);

}


double func(double x)
{
    return x+2;
}


void s_triangle()
{
    glBegin(GL_TRIANGLES); // DRAWING 3 SIDED TRIANGLE


         glColor3f(1.0f, 0.0f, 1.0f);
         glVertex2d(0.0,0.0);
         glColor3f(1.0f, 1.0f, 0.0f);
         glVertex2d(4.0,-2.0);
         glColor3f(1.0f, 0.0f, 0.0f);
         glVertex2d(4.0,2.0);

    glEnd();

}


void s_triangle2()
{
    glBegin(GL_TRIANGLES); // DRAWING 3 SIDED TRIANGLE

         glColor3f(1.0f, 0.0f, 1.0f);
         glVertex2d(0.0,0.0);
         glColor3f(1.0f, 1.0f, 0.0f);
         glVertex2d(-2.0,4.0);
         glColor3f(1.0f, 0.0f, 0.0f);
         glVertex2d(2.0,4.0);

    glEnd();

}








void house1()
{

     glPushMatrix();
     glTranslatef(30, -10, 0);
     glColor3f(v,v,w);
     draw_rec2();
     glPopMatrix();

     glPushMatrix();
     glTranslatef(55, -10, 0);
     glColor3f(v,v,w);
     draw_rec2();
     glPopMatrix();

     glPushMatrix();
     glTranslatef(30, 10, 0);
     glColor3f(v,v,w);
     draw_rec2();
     glPopMatrix();

     glPushMatrix();
     glTranslatef(55, 10, 0);
     glColor3f(v,v,w);
     draw_rec2();
     glPopMatrix();


     glPushMatrix();
     glTranslatef(30, 30, 0);
     glColor3f(v,v,w);
     draw_rec2();
     glPopMatrix();

     glPushMatrix();
     glTranslatef(55, 30, 0);
     glColor3f(v,v,w);
     draw_rec2();
     glPopMatrix();

     glPushMatrix();
     glTranslatef(40, -40, 0);
     glColor3f(v,v,w);
     glScaled(2,3,1);
     draw_rec2();
     glPopMatrix();


     glPushMatrix();
     glTranslatef(10, -5, 0);
     glColor3f(0.0,0.0,1.0);
     glScaled(1,10,1);
     draw_rec();
     glPopMatrix();

     glPushMatrix();
     glTranslatef(40, -5, 0);
     glColor3f(0.0,0.0,1.0);
     glScaled(5,10,1);
     draw_rec();
     glPopMatrix();

}

void house2()
{
     glPushMatrix();
     glTranslatef(100, 0, 0);
     glColor3f(v,v,w);
     draw_rec2();
     glPopMatrix();



     glPushMatrix();
     glTranslatef(100, 20, 0);
     glColor3f(v,v,w);
     draw_rec2();
     glPopMatrix();

     glPushMatrix();
     glTranslatef(100, -30, 0);
     glColor3f(v,v,w);
     glScaled(1.5,3,1);
     draw_rec2();
     glPopMatrix();

     glPushMatrix();
     glTranslatef(80, -5, 0);
     glColor3f(0.0,0.0,1.0);
     glScaled(1,8,1);
     draw_rec();
     glPopMatrix();

     glPushMatrix();
     glTranslatef(100, -5, 0);
     glColor3f(0.0,0.0,1.0);
     glScaled(3,8,1);
     draw_rec();
     glPopMatrix();

}

void windmill()
{
     glPushMatrix();
     glTranslatef(-50, 20, 0);
     glColor3f(0.0,0.0,1.0);
     glScaled(3,3,1);
     glRotatef(15*angle,0,0,1);
     s_triangle();
     glPopMatrix();

     glPushMatrix();
     glTranslatef(-50, 20, 0);
     glColor3f(0.0,0.0,1.0);
     glScaled(-3,3,1);
     glRotatef(-15*angle,0,0,1);
     s_triangle();
     glPopMatrix();

     glPushMatrix();
     glTranslatef(-50, 20, 0);
     glColor3f(0.0,0.0,1.0);
     glScaled(-3,3,1);
     glRotatef(-15*angle,0,0,1);
     s_triangle2();
     glPopMatrix();



     glPushMatrix();
     glTranslatef(-50, 20, 0);
     glColor3f(0.0,0.0,1.0);
     glScaled(3,-3,1);
     glRotatef(-15*angle,0,0,1);
     s_triangle2();
     glPopMatrix();


     glPushMatrix();
     glTranslatef(-49, -5, 0);
     glColor3f(0.5f, 0.3f, 0.1f);//Bronze
     glScaled(.3,5,1);
     draw_rec2();
     glPopMatrix();


}


void windmill2()
{
     glPushMatrix();
     glTranslatef(-100, 20, 0);
     glColor3f(0.0,0.0,1.0);
     glScaled(3,3,1);
     glRotatef(15*angle,0,0,1);
     s_triangle();
     glPopMatrix();

     glPushMatrix();
     glTranslatef(-100, 20, 0);
     glColor3f(0.0,0.0,1.0);
     glScaled(-3,3,1);
     glRotatef(-15*angle,0,0,1);
     s_triangle();
     glPopMatrix();

     glPushMatrix();
     glTranslatef(-100, 20, 0);
     glColor3f(0.0,0.0,1.0);
     glScaled(-3,3,1);
     glRotatef(-15*angle,0,0,1);
     s_triangle2();
     glPopMatrix();



     glPushMatrix();
     glTranslatef(-100, 20, 0);
     glColor3f(0.0,0.0,1.0);
     glScaled(3,-3,1);
     glRotatef(-15*angle,0,0,1);
     s_triangle2();
     glPopMatrix();


     glPushMatrix();
     glTranslatef(-98, -5, 0);
     glColor3f(0.5f, 0.3f, 0.1f);
     glScaled(.3,5,1);
     draw_rec2();
     glPopMatrix();


}








void windmill3()
{
     glPushMatrix();
     glTranslatef(-70, -10, 0);
     glColor3f(0.0,0.0,1.0);
     glScaled(3,3,1);
     glRotatef(15*angle,0,0,1);
     s_triangle();
     glPopMatrix();

     glPushMatrix();
     glTranslatef(-70, -10, 0);
     glColor3f(0.0,0.0,1.0);
     glScaled(-3,3,1);
     glRotatef(-15*angle,0,0,1);
     s_triangle();
     glPopMatrix();

     glPushMatrix();
     glTranslatef(-70, -10, 0);
     glColor3f(0.0,0.0,1.0);
     glScaled(-3,3,1);
     glRotatef(-15*angle,0,0,1);
     s_triangle2();
     glPopMatrix();



     glPushMatrix();
     glTranslatef(-70, -10, 0);
     glColor3f(0.0,0.0,1.0);
     glScaled(3,-3,1);
     glRotatef(-15*angle,0,0,1);
     s_triangle2();
     glPopMatrix();


     glPushMatrix();
     glTranslatef(-68.5, -34, 0);
     glColor3f(0.5f, 0.3f, 0.1f);
     glScaled(.3,5,1);
     draw_rec2();
     glPopMatrix();


}

void sky()
{
    glPushMatrix();
    glTranslatef(0,30,0);
    glBegin(GL_QUADS);

        glColor3f(0, 0.5, .5);
        glVertex2d(200, 100);

        glColor3f(.0, .8, .9);
        glVertex2d(-200, 100);

        glColor3f(0, 0, 1);
        glVertex2d(-200, 0);

        glColor3f(.0, .9, 1);
        glVertex2d(200, 0);

    glEnd();

    glPopMatrix();
}

void sun ()
{
    glPushMatrix();
    glTranslatef(-20,90,0);
    glColor3f(1, .77, 0);
    drawCircle(15,15);
    glPopMatrix();

}

void cloud1 ()
{

glPushMatrix();

    glTranslatef(100-q,0,0);
    glTranslatef(0,15,0);

    glPushMatrix();
    glTranslatef(-51,79,0);
    glColor3f(1, .9, .9);

    drawCircle(10,8);
    glPopMatrix();


    glPushMatrix();
    glTranslatef(-75,75,0);
    glColor3f(1, .9, .9);
    drawCircle(10,8);
    glPopMatrix();


    glPushMatrix();
    glTranslatef(-60,77,0);
    glColor3f(1, .9, .9);
    drawCircle(15,12);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-70,73,0);
    glColor3f(1, .9, .9);
    drawCircle(12,10);
    glPopMatrix();

 glPopMatrix();

}


 void cloud2 ()
{

glPushMatrix();

    glTranslatef(200-q2,0,0);
    glTranslatef(0,15,0);

    glPushMatrix();
    glTranslatef(-51,79,0);
    glColor3f(1, .9, .9);

    drawCircle(10,8);
    glPopMatrix();


    glPushMatrix();
    glTranslatef(-75,75,0);
    glColor3f(1, .9, .9);
    drawCircle(10,8);
    glPopMatrix();


    glPushMatrix();
    glTranslatef(-60,77,0);
    glColor3f(1, .9, .9);
    drawCircle(15,12);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-70,73,0);
    glColor3f(1, .9, .9);
    drawCircle(12,10);
    glPopMatrix();

 glPopMatrix();

 }


void hill ()
{
    glPushMatrix();
    glTranslatef(-100,30,0);
    glBegin(GL_POLYGON);

        glColor3f(.55, .27, .075);
        glVertex2d(30, 0);

        glColor3f(.9, .7, .3);
        glVertex2d(0, 30);

        glColor3f(.3, .9, .5);
        glVertex2d(-30, -0);

    glEnd();
    glPopMatrix();


    glPushMatrix();
    glTranslatef(-60,30,0);
    glBegin(GL_POLYGON);

        glColor3f(.55, .27, .075);
        glVertex2d(30, 0);

        glColor3f(.9, .7, .3);
        glVertex2d(0, 30);

        glColor3f(.3, .9, .5);
        glVertex2d(-30, 0);

    glEnd();
    glPopMatrix();


    glPushMatrix();
    glTranslatef(-82,30,0);
    glBegin(GL_POLYGON);

        glColor3f(.55, .27, .075);
        glVertex2d(25, 0);

        glColor3f(.9, .7, .3);
        glVertex2d(0, 30);

        glColor3f(.3, .9, .5);
        glVertex2d(-25, -0);

    glEnd();
    glPopMatrix();


    glPushMatrix();
    glTranslatef(85,30,0);
    glBegin(GL_POLYGON);

        glColor3f(.3, .9, .5);
        glVertex2d(30, 0);

        glColor3f(.55, .27, .075);
        glVertex2d(0, 30);


        glColor3f(.9, .7, .3);
        glVertex2d(-30, 0);

    glEnd();
    glPopMatrix();



    glPushMatrix();
    glTranslatef(110,30,0);
    glBegin(GL_POLYGON);

        glColor3f(.55, .27, .075);
        glVertex2d(30, 0);

        glColor3f(.9, .7, .3);
        glVertex2d(0, 30);

        glColor3f(.3, .9, .5);
        glVertex2d(-30, 0);

    glEnd();
    glPopMatrix();
}

void river ()
{
    glPushMatrix();
    glTranslatef(0,-35,0);
    glBegin(GL_QUADS);

        glColor3f(1, 1, 1);
        glVertex2d(200, 65);

        glColor3f(0, 1, 1);
        glVertex2d(-200, 65);

        glColor3f(1, 1, 1);
        glVertex2d(-200, 20);

        glColor3f(0, 1, 1);
        glVertex2d(200, 20);

    glEnd();
    glPopMatrix();
}


void ground ()
{
    glPushMatrix();
    glTranslatef(0,-35,0);
    glBegin(GL_QUADS);

        glColor3f(1, 1, 1);
        glVertex2d(200, 20);

        glColor3f(.3, .7,0);
        glVertex2d(-200, 20);

        glColor3f(.9, .9, .9);
        glVertex2d(-200, -200);

        glColor3f(.3, .5, 0);
        glVertex2d(200, -200);

    glEnd();
    glPopMatrix();
}

void road()
{
     glPushMatrix();
     glTranslatef(-100, -80, 0);
     glColor3f(.3,.3,.3);
     glScaled(100,4,1);
     draw_rec2();
     glPopMatrix();


     glPushMatrix();
     glTranslatef(-20, -40, 0);
     glColor3f(.3,.3,.3);
     glScaled(2,5,1);
     draw_rec2();
     glPopMatrix();
}



void display()
{

	//clear the display
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glClearColor(0,0,0,0);	//color black
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


	//load the correct matrix -- MODEL-VIEW matrix
	glMatrixMode(GL_MODELVIEW);

	//initialize the matrix
	glLoadIdentity();

	//now give three info
	//1. where is the camera (viewer)?
	//2. where is the camera looking?
	//3. Which direction is the camera's UP direction?

	//gluLookAt(100,100,100,	0,0,0,	0,0,1);
//	gluLookAt(200*cos(cameraAngle), 200*sin(cameraAngle), cameraHeight,		0,0,0,		0,0,1);
	gluLookAt(0,0,100,	0,0,0,	0,100,0);


	//again select MODEL-VIEW
	glMatrixMode(GL_MODELVIEW);

    //drawAxes();
    house1();
    house2();
    windmill();
    windmill2();
    windmill3();
    cloud1();
    cloud2();
    sun();
    hill();
    river();
    sky();
    road();
    ground();



	//ADD this line in the end --- if you use double buffer (i.e. GL_DOUBLE)
	glutSwapBuffers();
}


void animate()
{
    //rotation
    angle-=.5;

	//codes for any changes in Models, Camera
	//linear_oscillation

    incx = func(incy);

	glutPostRedisplay();
}


void spin(void)
{
    v=1;
	w=0;


	if(q>=-100.0)
    {
        q=q-0.05;
    }
    else
    {
        q=120;
    }



     if(q2>=-180.0)
     {
        q2=q2-0.05;
     }
    else
    {
        q2=200;
    }

     animate();
	 display();

 }

void menu(int id )
{
	switch(id)
	{



	case 1: glutIdleFunc(spin);

			break;

    case 2: v=w=0.3;

            glutIdleFunc(display);
            break;

	case 3: exit(0);

	}
}


void init(){
	//codes for initialization
	drawgrid=0;
	drawaxes=1;
	cameraHeight=150.0;
	cameraAngle=1.0;
	angle=0;

	//clear the screen
	glClearColor(0,0,0,0);


	//load the PROJECTION matrix
	glMatrixMode(GL_PROJECTION);

	//initialize the matrix
	glLoadIdentity();

	//give PERSPECTIVE parameters
	gluPerspective(100,	1,	1,	1000.0);
	//field of view in the Y (vertically)
	//aspect ratio that determines the field of view in the X direction (horizontally)
	//near distance
	//far distance
}

int main(int argc, char **argv)
{
	glutInit(&argc,argv);
	glutInitWindowSize(800, 600);
	glutInitWindowPosition(100, 100);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGB);	//Depth, Double buffer, RGB color

	glutCreateWindow("My OpenGL Program");

	init();


	glEnable(GL_DEPTH_TEST);	//enable Depth Testing

	glutDisplayFunc(display);	//display callback function	//what you want to do in the idle time (when no drawing is occuring)

    printf("Please Click Right on Your Mouse for Menu!!!");

    glutCreateMenu(menu);
    glutAddMenuEntry("Light ON",1);
	glutAddMenuEntry("Light OFF",2);
	glutAddMenuEntry("Quit",3);
	glutAttachMenu(GLUT_RIGHT_BUTTON);

	//glutKeyboardFunc(keyboardListener);
	//glutSpecialFunc(specialKeyListener);
	//glutMouseFunc(mouseListener);

	glutMainLoop();		//The main loop of OpenGL

	return 0;
}
